const express = require('express');
const path = require('path');
const neo4j = require('neo4j-driver');
const app = express();
const port = 5500;
const USER = 'neo4j';
const PASSWORD = '12345678';
let driver;

// Manejar el cierre de la aplicación
process.on('exit', () => {
    if (driver) {
        console.log('Cerrando la conexión a Neo4j al salir de la aplicación.');
        driver.close();
    }
});

process.on('SIGINT', () => {
    if (driver) {
        console.log('Manejando la señal SIGINT. Cerrando la conexión a Neo4j.');
        driver.close();
        process.exit();
    }
});

async function connectToNeo4j(orderByColumn = 'id') {
    try {
        driver = neo4j.driver('bolt://localhost:7687', neo4j.auth.basic(USER, PASSWORD));
        const session = driver.session();

        // Añade la ordenación a la consulta
        const result = await session.run(`MATCH (n) RETURN n ORDER BY n.${orderByColumn} LIMIT 100`);

        const nodes = result.records.map(record => {
            const nodeProperties = record.get(0).properties;

            return {
                id: record.get(0).identity.toString(),
                organizationId: nodeProperties.Index ? nodeProperties.Index.toNumber() : null,
                name: nodeProperties.Name,
                website: nodeProperties.Website,
                country: nodeProperties.Country,
                description: nodeProperties.Description,
                founded: nodeProperties.Founded ? nodeProperties.Founded.toNumber() : null,
                industry: nodeProperties.Industry,
                employees: nodeProperties.Employees ? nodeProperties.Employees.toNumber() : null,
            };
        });

        await session.close();

        return nodes;
    } catch (err) {
        console.error(`Connection error\n${err}\nCause: ${err.cause}`);
        throw err;
    }
}

app.get('/', async (req, res) => {
    try {
        const nodes = await connectToNeo4j();
        res.sendFile(path.join(__dirname, 'index.html'));
    } catch (error) {
        res.status(500).send('Error interno del servidor');
    }
});

app.get('/customers', async (req, res) => {
    try {
        const orderByColumn = req.query.orderBy || 'id'; // Obtén el parámetro de orden desde la consulta
        const nodes = await connectToNeo4j(orderByColumn);
        res.json(nodes);
    } catch (error) {
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:${port}`);
});

app.delete('/delete-node/:id', async (req, res) => {
    try {
        const nodeId = req.params.id;

        if (!nodeId) {
            return res.status(400).json({ error: 'El ID del nodo es obligatorio.' });
        }

        const session = driver.session();

        // Ejecutar la consulta para eliminar el nodo por su ID
        const result = await session.run('MATCH (n) WHERE ID(n) = $nodeId DELETE n', {
            nodeId: parseInt(nodeId),
        });

        await session.close();

        res.status(200).json({ message: 'Nodo eliminado exitosamente' });
    } catch (error) {
        console.error(`Error al eliminar el nodo\n${error}\nCause: ${error.cause}`);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

app.post('/add-node', express.json(), async (req, res) => {
    try {
        const { name, website, country, description, founded, industry, employees } = req.body;

        if (!name || !website || !country || !description || !founded || !industry || !employees) {
            return res.status(400).json({ error: 'Todos los campos son obligatorios.' });
        }

        const session = driver.session();

        // Consultar el máximo organizationId actual
        const maxOrganizationIdResult = await session.run('MATCH (n:Node) RETURN max(n.organizationId) AS maxId');
        const maxOrganizationId = maxOrganizationIdResult.records[0].get('maxId');
        const newOrganizationId = maxOrganizationId !== null ? (typeof maxOrganizationId === 'object' ? maxOrganizationId.toNumber() : maxOrganizationId) + 1 : 1;

        // Crear el nuevo nodo con el nuevo organizationId
        const result = await session.run(
            'CREATE (n:Organization {organizationId: $organizationId, name: $name, website: $website, country: $country, description: $description, founded: $founded, industry: $industry, employees: $employees}) RETURN n',
            {
                organizationId: newOrganizationId,
                name,
                website,
                country,
                description,
                founded: founded ? parseInt(founded) : null, // Asegurar que founded sea un número o null
                industry,
                employees: employees ? parseInt(employees) : null, // Asegurar que employees sea un número o null
            }
        );

        const newNodeProperties = result.records[0].get(0).properties;
        const newNode = {
            id: result.records[0].get(0).identity.toString(),
            organizationId: newNodeProperties.organizationId !== null && typeof newNodeProperties.organizationId !== 'undefined' && newNodeProperties.organizationId.hasOwnProperty('toNumber') ? newNodeProperties.organizationId.toNumber() : null,
            name: newNodeProperties.name,
            website: newNodeProperties.website,
            country: newNodeProperties.country,
            description: newNodeProperties.description,
            founded: newNodeProperties.founded !== null && typeof newNodeProperties.founded !== 'undefined' && newNodeProperties.founded.hasOwnProperty('toNumber') ? newNodeProperties.founded.toNumber() : null,
            industry: newNodeProperties.industry,
            employees: newNodeProperties.employees !== null && typeof newNodeProperties.employees !== 'undefined' && newNodeProperties.employees.hasOwnProperty('toNumber') ? newNodeProperties.employees.toNumber() : null,
        };

        await session.close();
        res.status(201).json({ message: 'Nodo creado exitosamente', newNode });
    } catch (error) {
        console.error(`Error al crear el nodo\n${error}\nCause: ${error.cause}`);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});
async function createRelationshipsByFoundedYear() {
    try {
        const session = driver.session();

        // Obtener nodos organización ordenados por año de fundación
        const result = await session.run('MATCH (n:Organization) RETURN n ORDER BY n.Founded');

        const nodesByYear = {};

        // Agrupar nodos por año de fundación
        result.records.forEach(record => {
            const node = record.get(0);
            const foundedYear = node.properties.Founded ? node.properties.Founded.toNumber() : null;

            if (foundedYear) {
                if (!nodesByYear[foundedYear]) {
                    nodesByYear[foundedYear] = [];
                }

                nodesByYear[foundedYear].push(node);
            }
        });

        // Crear relaciones entre nodos del mismo año
        for (const year in nodesByYear) {
            const nodes = nodesByYear[year];

            for (let i = 0; i < nodes.length; i++) {
                for (let j = i + 1; j < nodes.length; j++) {
                    const node1 = nodes[i];
                    const node2 = nodes[j];

                    await session.run('CREATE (n1)-[:FUNDADA_EL_MISMO_ANO]->(n2)', { n1, n2 });
                }
            }
        }

        await session.close();
        console.log('Relaciones creadas exitosamente.');
    } catch (error) {
        console.error(`Error al crear relaciones\n${error}\nCause: ${error.cause}`);
        throw error;
    }
}

