document.addEventListener('DOMContentLoaded', () => {
    fetchAndPopulateTable();
    const tableContainer = document.getElementById('table-container');
    tableContainer.addEventListener('scroll', handleTableScroll);

    const searchInput = document.getElementById('search');
    const searchParameter = document.getElementById('search-parameter');
    searchInput.addEventListener('input', debounce(() => filterTable(searchParameter.value), 300));
    searchParameter.addEventListener('change', () => filterTable(searchParameter.value));
    const addNodeButton = document.getElementById('add-node-button');
    addNodeButton.addEventListener('click', toggleAddNodeForm);

    const addNodeForm = document.getElementById('add-node-form');
    addNodeForm.addEventListener('submit', function (event) {
        event.preventDefault();
        addNode(); // Cambiado para llamar a addNode en lugar de la función anteriormente llamada addNodeButton
    });

    const config = {
        container_id: 'graph-container',
        server_url: 'bolt://localhost:7687',
        server_user: 'neo4j',
        server_password: '12345678',
        labels: {
            'Organization': {
                caption: 'name', // Puedes ajustar esto según la propiedad que desees mostrar en los nodos
            },
        },
        relationships: {
            'RELATED_TO': {},
        },
        initial_cypher: 'MATCH (o:Organization)-[:RELATED_TO]-(other) RETURN o, other',
        arrows: true,
        hierarchical: false,
    };
    // Actualiza la tabla cuando se elimina un nodo
    document.getElementById('delete-node-form').addEventListener('submit', (event) => {
        event.preventDefault();
        deleteNode();
    });
    const visualization = new Neovis(config);
    visualization.render();

});
function toggleAddNodeForm() {
    const addNodeFormContainer = document.getElementById('node-form-container');
    addNodeFormContainer.style.display = addNodeFormContainer.style.display === 'none' ? 'block' : 'none';
}

function addNode() {
    const nodeName = document.getElementById('node-name').value;
    const nodeWebsite = document.getElementById('node-website').value;
    const nodeCountry = document.getElementById('node-country').value;
    const nodeDescription = document.getElementById('node-description').value;
    const nodeFounded = document.getElementById('node-founded').value;
    const nodeIndustry = document.getElementById('node-industry').value;
    const nodeEmployees = document.getElementById('node-employees').value;

    // Validar que los campos no estén vacíos u otros criterios según tus necesidades
    if (!nodeName.trim() || !nodeWebsite.trim() || !nodeCountry.trim() || !nodeDescription.trim() || !nodeFounded.trim() || !nodeIndustry.trim() || !nodeEmployees.trim()) {
        alert('Por favor, ingrese valores válidos para todos los campos.');
        return;
    }

    const newNodeData = {
        name: nodeName,
        website: nodeWebsite,
        country: nodeCountry,
        description: nodeDescription,
        founded: nodeFounded,
        industry: nodeIndustry,
        employees: nodeEmployees,
    };

    // Enviar los datos al servidor para agregar el nuevo nodo
    fetch('/add-node', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(newNodeData),
    })
        .then(response => response.json())
        .then(result => {
            console.log(result.message);
            toggleAddNodeForm(); // Oculta el formulario después de agregar el nodo.
            fetchDataAndPopulateTable(); // Vuelve a cargar la tabla después de agregar un nodo.
        })
        .catch(error => {
            console.error('Error al agregar el nodo:', error);
            alert('Error al agregar el nodo. Consulte la consola para obtener más detalles.');
        });
}
function deleteNode() {
    const nodeIdInput = document.getElementById('delete-node-id');
    const nodeId = nodeIdInput.value.trim();

    if (!nodeId) {
        alert('Ingresa un ID válido');
        return;
    }

    if (confirm(`Confirma que el nodo a eliminar será: ${nodeId}`)) {
        // Enviar la solicitud al servidor para eliminar el nodo por su ID
        fetch(`/delete-node/${nodeId}`, {
            method: 'DELETE',
        })
            .then(response => {
                if (response.ok) {
                    // Actualizar la tabla después de eliminar el nodo
                    fetchAndPopulateTable();
                    nodeIdInput.value = ''; // Limpiar el campo de entrada
                } else {
                    console.error('Error al eliminar el nodo:', response.statusText);
                    alert('Error al eliminar el nodo. Consulte la consola para obtener más detalles.');
                }
            })
            .catch(error => {
                console.error('Error al eliminar el nodo:', error);
                alert('Error al eliminar el nodo. Consulte la consola para obtener más detalles.');
            });
    }
}

function debounce(func, delay) {
    let timeoutId;
    return function () {
        const context = this;
        const args = arguments;
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
            func.apply(context, args);
        }, delay);
    };
}

function handleTableScroll() {
    const tableContainer = document.getElementById('table-container');
    const headerRow = document.getElementById('header-row');
    const scrollPosition = tableContainer.scrollTop;

    headerRow.style.position = scrollPosition > 0 ? 'sticky' : '';
    headerRow.style.top = scrollPosition > 0 ? '0' : '';
}

let selectedColumn = 'id';

function filterTable(selectedColumn) {
    const input = document.getElementById('search');
    const filter = input.value.toUpperCase();
    const table = document.getElementById('data-table');
    const rows = table.getElementsByTagName('tr');

    const columnIndex = Array.from(table.querySelector('thead').children[0].children).findIndex(th => th.textContent.toLowerCase() === selectedColumn);

    for (let i = 1; i < rows.length; i++) {
        const cells = rows[i].getElementsByTagName('td');
        let found = false;

        const cellText = cells[columnIndex].innerText || cells[columnIndex].textContent;

        if (cellText.toUpperCase().includes(filter)) {
            found = true;
        }

        rows[i].style.display = found ? '' : 'none';
    }

    const searchResultsDiv = document.getElementById('search-results');
    searchResultsDiv.innerHTML = '';
}

function fetchAndPopulateTable() {
    fetch('/customers')
        .then(response => response.json())
        .then(data => {
            const dataContainer = document.getElementById('data-container');
            const dataTable = document.getElementById('data-table');

            // Limpiar la tabla antes de agregar nuevos datos
            dataContainer.innerHTML = '';

            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
            <td>${row.id}</td>
            <td>${row.organizationId}</td>
            <td>${row.name}</td>
            <td>${row.website}</td>
            <td>${row.country}</td>
            <td>${row.description}</td>
            <td>${row.founded}</td>
            <td>${row.industry}</td>
            <td>${row.employees}</td>
          `;
                dataContainer.appendChild(tr);
            });

            // Ordena automáticamente por la columna ID al cargar la tabla
            sortTable('id');

            dataTable.style.display = 'table';
        })
        .catch(error => console.error('Error fetching data:', error));
}

let sortOrder = 'asc'; // Variable para rastrear el orden actual

function sortTable(column) {
    const table = document.getElementById('data-table');
    const tbody = document.getElementById('data-container');
    const rows = Array.from(tbody.getElementsByTagName('tr'));

    // Obtén el índice de la columna seleccionada
    const columnIndex = Array.from(table.querySelector('thead').children[0].children)
        .findIndex(th => th.textContent.toLowerCase().includes(column.toLowerCase()));

    // Función de comparación para ordenar en función del valor y el orden
    const compareFunction = (a, b) => {
        const aValue = getColumnValue(a, columnIndex);
        const bValue = getColumnValue(b, columnIndex);

        if (sortOrder === 'asc') {
            return aValue > bValue ? 1 : -1;
        } else {
            return aValue < bValue ? 1 : -1;
        }
    };

    // Ordena las filas utilizando la función de comparación
    const sortedRows = rows.sort(compareFunction);

    // Cambia el orden para la próxima vez
    sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';

    // Elimina las filas actuales
    tbody.innerHTML = '';

    // Agrega las filas ordenadas de nuevo a la tabla
    sortedRows.forEach(row => {
        tbody.appendChild(row);
    });
}

function getColumnValue(row, columnIndex) {
    const cellValue = row.getElementsByTagName('td')[columnIndex].innerText.trim();
    return isNaN(cellValue) ? cellValue : parseInt(cellValue, 10);
}
